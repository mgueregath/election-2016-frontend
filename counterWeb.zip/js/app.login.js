$(document).ready(function () {
  $("button[type=submit]").click(function (e) {
    e.preventDefault();
    var data = {
      "id": parseInt($("#location-id").val()),
      "password": $("#location-password").val()
    }
    Api.login(
      JSON.stringify(data),
      function(data) {
        Stg.add(data.data[0].Authorization);
        window.location.hash = "/mesas";
      },
      function(data) {
        
      }
    )
  });
});