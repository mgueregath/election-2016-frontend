if (tableId === undefined || tableId === null) {
  window.location.hash = "/mesas";
}

$(document).ready( function() {
  Api.getTable(
    tableId,
    function (data) {
      if (data.result === true) {
        var tableResult = data.data[0];
        $("#sabat").val(tableResult.sabat);
        $("#gomez").val(tableResult.gomez);
        $("#ilabaca").val(tableResult.ilabaca);
        $("#carrasco").val(tableResult.carrasco);
        $("#blanks").val(tableResult.blanks);
        $("#nulls").val(tableResult.nulls);
      }
    },
    function () {
      
    }
  );
  
  Api.getJoinedTables(
    tableId,
    function (data) {
      if(data.result === true) {
        var joindeTables = data.data[0].tables;
        $.each(joindeTables, function (index, value) {
          value = value[0];
          if (value.id !== parseInt(tableId)) {
            var div = '<a href="#/mesas" id="' + value.id + '" class="list-group-item">' + value.descriptor + '</a>';

            $("#table .list-group").append(div);
          } else {
            $("#table-descriptor").html(value.descriptor);
          }
        });
      }
    },
    function () {
      
    }
  );
  
  
  $("button[type=button]#register").click(function() {
    
    var data = {
      table_id: tableId,
      sabat: $("#sabat").val(),
      gomez: $("#gomez").val(),
      ilabaca: $("#ilabaca").val(),
      carrasco: $("#carrasco").val(),
      blanks: $("#blanks").val(),
      nulls: $("#nulls").val()
    }
    
    Api.registerTable(
      JSON.stringify(data),
      function(data) {
        console.log(data);
      },
      function(data) {

      }
    );
  });
  
  $("button[type=button]#join").click(function() {
    var data = {
      "second_table": $("#select-table").val()
    }
    Api.joinTables(
      tableId,
      JSON.stringify(data),
      function (data) {
        
      },
      function () {
        
      }
    );
    
  });
  
  $("button[type=button]#show-modal").click(function() {
    Api.getTables(
      function (data) {
        var tables = data.data;
        Api.getJoinedTables(
          tableId,
          function (data) {
            $("#select-table").empty();
            var joinedTables = data.data[0].tables;
            var jT = [];
            $.each(joinedTables, function (index, value) {       
              jT.push(value[0]);
            });
            $.each(tables, function (index, value) {
              if (!isInArray(jT, value.id, true)) {
                var option = '<option value="' + value.id + '">' + value.descriptor + '</option>';
                $("#select-table").append(option);
              }
            });
          },
          function () {
            
          }
        );
      },
      function () {
        
      }    
    );
    
  });
  
  function isInArray(inArr, id, exists) {
    for (i = 0; i < inArr.length; i++ ) {
      if (inArr[i].id == id) {
        return (exists === true) ? true : inArr[i];
      }
    }
  }
  
});