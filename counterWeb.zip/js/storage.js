"use_strict";

var Stg = {};

Stg.add = function(token) {
    localStorage.setItem("usr_tkn", token);
};

Stg.remove = function() {
    localStorage.removeItem("usr_tkn");
};

Stg.get = function() {
    if (localStorage.getItem("usr_tkn")) {
        return "Bearer " + localStorage.getItem("usr_tkn");
    }
    return null;    
};
