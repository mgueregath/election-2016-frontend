var tableId;
$(document).ready(function () {
  Api.getTables(
  function(data) {
    
    if(data.result == true){
      $.each(data.data, function (index, value) {
        var div = '<a href="#/mesas" id="' + value.id + '" class="list-group-item">' + value.descriptor + '</a>';
                
        $("#tables .list-group").append(div);
        
        $("#" + value.id +".list-group-item").click(function(e) {
          e.preventDefault();
          tableId = $(this).attr("id");
          window.location.hash = "/mesa";
        });
      });
      
    }
    
  },
  function(data) {
    
  });
});